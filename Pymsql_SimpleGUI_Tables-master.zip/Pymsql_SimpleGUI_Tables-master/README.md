# Pymsql_SimpleGUI_Tables
Using PySimpleGUI in order to visualize Data from SQL Tables

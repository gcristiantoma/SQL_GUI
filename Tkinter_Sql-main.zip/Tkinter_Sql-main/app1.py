from tkinter import *
import tkinter.messagebox as MessageBox
import sqlite3
from bk import *

root=Tk()
root.geometry("600x600")
root.title("TEst")

# Define functions
def insert():
    id=e_id.get()
    name=e_name.get()
    phone=e_phone.get()

    if(id=="" or name=="" or phone==""):
        MessageBox.showinfo("Insert Status","All fields are requiered")
    else:
        conn = sqlite3.connect('contacts.db')
        cursor = conn.cursor()
        cursor.execute("insert into agenda values( '" + id + "','" + name + "','" + phone + "')")
        cursor.execute("commit;")
        cursor.close()


        #clear the form
        e_id.delete(0,"end")
        e_phone.delete(0,"end")
        e_name.delete(0,"end")

        # Update the values in the listbox
        show()

        MessageBox.showinfo("Insert Status","Inserted Successfully")

def delete():
    if(e_id.get()==""):
        MessageBox.showinfo("Delete Status","Id is requested for delete")
    else:
       conn = sqlite3.connect('contacts.db')
       cursor = conn.cursor()
       cursor.execute("delete from agenda where id='" + e_id.get() + "'")
       cursor.execute("commit;")
       cursor.close()

       # clear the form
       e_id.delete(0, "end")
       e_phone.delete(0, "end")
       e_name.delete(0, "end")

       # Update the values in the listbox
       show()

       MessageBox.showinfo("Delete Status", "Id is deleted Succesfully")

def update():
    id=e_id.get()
    name=e_name.get()
    phone=e_phone.get()

    if (id == "" or name == "" or phone == ""):
        MessageBox.showinfo("Insert Status", "All fields are requiered")
    else:
        conn = sqlite3.connect('contacts.db')
        cursor = conn.cursor()
        cursor.execute("update agenda set name='" + name + "',phone='" + phone + "' where id='" + id + "'")
        cursor.execute("commit;")
        cursor.close()

        # clear the form
        e_id.delete(0, "end")
        e_phone.delete(0, "end")
        e_name.delete(0, "end")

        # Update the values in the listbox
        show()

        MessageBox.showinfo("Update Status", "Updated Successfully")

def get():
    if (e_id.get() == ""):
        MessageBox.showinfo("Fetch Status", "Id is requested for Display")
    else:
        conn = sqlite3.connect('contacts.db')
        cursor = conn.cursor()
        cursor.execute("select * from agenda where id='" + e_id.get() + "'")
        rows=cursor.fetchall()
        cursor.close()
        for row in rows:
           e_name.insert(0,row[1])
           e_phone.insert(0, row[2])

def show():
    conn = sqlite3.connect('contacts.db')
    cursor = conn.cursor()
    res = cursor.execute("select * from agenda;")
    rows = res.fetchall()

    #clear the Listbox before printing new values
    list.delete(0,list.size())

    for row in rows:
        insertData=str(row[0])+"  "+row[1]
        list.insert(list.size()+1,insertData)
    cursor.close()

# Add Labels
id=Label(root,text="enter id",font=("bold",10))

id.place(x=20,y=30)
name=Label(root,text="enter name",font=("bold",10))
name.place(x=20,y=60)
phone=Label(root,text="enter phone",font=("bold",10))
phone.place(x=20,y=90)

#Add entry forms
e_id=Entry()
e_id.place(x=150,y=30)

e_name=Entry()
e_name.place(x=150,y=60)

e_phone=Entry()
e_phone.place(x=150,y=90)

#Creating Buttons
insert=Button(root,text="insert",command=insert)
insert.place(x=20,y=140)

delete=Button(root,text="delete",command=delete)
delete.place(x=100,y=140)

update=Button(root,text="update",command=update)
update.place(x=190,y=140)

get=Button(root,text="Get 1 record by ID",command=get)
get.place(x=270,y=140)

#Listbox Displays

list=Listbox(root)
list.place(x=20,y=180)
show()

root.mainloop()

import sqlite3
conn=sqlite3.connect('contacts.db')
cursor=conn.cursor()
cursor.execute("select * from agenda")

print(cursor.fetchall())

#con.execute(""" CREATE TABLE IF NOT EXISTS agenda (
#                                         id integer PRIMARY KEY,
#                                         name text NOT NULL,
#                                         phone integer
#                                         ); """)
# res=con.execute("""select * from agenda;""")
# print(res.fetchall())



# connection.commit()
# connection.close()